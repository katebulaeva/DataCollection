# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient


class JobparserPipeline:

    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongobase = client.vacancy_scrapy

    def process_item(self, item, spider):
        if spider.name == 'superjob':
            item['min_sal'], item['max_sal'], item['cur'] = self.process_salary(item['salary'])
            del item['salary']
        #

        collection = self.mongobase[spider.name]
        collection.insert_one(item)
        return item

    def process_salary(self, salary):
        min_sal = []
        max_sal = []
        cur = []
        try:
            #print(salary)

            if salary[0] == 'от':
                min_sal.append(salary[2])
                min_sal = ' '.join(min_sal).replace('\xa0', '')
                min_sal = int(min_sal[:-4])
                max_sal = None
                cur.append(salary[2])
                cur = ' '.join(cur).replace('\xa0', '')
                cur = cur[-4:]

            elif salary[2] == '—':
                min_sal.append(salary[0])
                min_sal = int(' '.join(min_sal).replace('\xa0', ''))

                max_sal.append(salary[4])
                max_sal = int(' '.join(max_sal).replace('\xa0', ''))

                cur.append(salary[6])
                cur = ' '.join(cur)

            elif salary[0] == 'до':
                min_sal = None
                max_sal.append(salary[2])
                max_sal = ' '.join(max_sal).replace('\xa0', '')
                max_sal = int(max_sal[:-4])
                #max_sal = int(' '.join(map(str, min_sal)))
                cur.append(salary[2])
                cur = ' '.join(cur).replace('\xa0', '')
                cur = cur[-4:]

        except:
            min_sal = None
            max_sal = None
            cur = None

        return min_sal, max_sal, cur